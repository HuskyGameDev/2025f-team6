using UnityEngine;
using UnityEngine.SceneManagement;

public class GoToRebindMenu : MonoBehaviour
{
    public void Go()
    {
        SceneManager.LoadScene("RebindMenu");
    }
}
